"""
Moovent Stack launcher package.

This repo intentionally keeps the launcher small:
- access checks (revocation)
- remote-only mode (Render)
"""

